﻿/*
 * Program : Ultrapowa Clash Server
 * Description : A C# Writted 'Clash of Clans' Server Emulator !
 *
 * Authors:  Jean-Baptiste Martin <Ultrapowa at Ultrapowa.com>,
 *           And the Official Ultrapowa Developement Team
 *
 * Copyright (c) 2016  UltraPowa
 * All Rights Reserved.
 */

namespace UCS.Core.Crypto.TweetNaCl
{
    public class xsalsa20
    {
        internal readonly int crypto_stream_xsalsa20_ref_KEYBYTES = 32;
        internal readonly int crypto_stream_xsalsa20_ref_NONCEBYTES = 24;

        public static readonly byte[] sigma = new byte[] {(byte) 'e', (byte) 'x', (byte) 'p', (byte) 'a', (byte) 'n', (byte) 'd', (byte) ' ', (byte) '3', (byte) '2', (byte) '-', (byte) 'b', (byte) 'y', (byte) 't', (byte) 'e', (byte) ' ', (byte) 'k'};

        public static int crypto_stream(byte[] c, int clen, byte[] n, byte[] k)
        {
            byte[] subkey = new byte[32];

            hsalsa20.crypto_core(subkey, n, k, sigma);
            return salsa20.crypto_stream(c, clen, n, 16, subkey);
        }

        public static int crypto_stream_xor(byte[] c, byte[] m, long mlen, byte[] n, byte[] k)
        {
            byte[] subkey = new byte[32];

            hsalsa20.crypto_core(subkey, n, k, sigma);
            return salsa20.crypto_stream_xor(c, m, (int) mlen, n, 16, subkey);
        }
    }
}